/// <reference path="Auto.ts"/>

let auto:Clases.Auto = new Clases.Auto("aaa123","Ford",100000);
console.log(JSON.stringify(auto.ToJson()));