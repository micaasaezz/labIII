namespace Enlace{
    export class Manejadora
    {
        public static Agregar():void
        {
            let patente: string = (<HTMLInputElement>document.getElementById("txtPatente")).value;
            let marca: string = (<HTMLInputElement>document.getElementById("cboMarca")).value;
            let precio: number = <number><any>(<HTMLInputElement>document.getElementById("txtPrecio")).value;
        
            var auto = new Clases.Auto(patente, marca, precio);
            
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            if((<HTMLInputElement>document.getElementById("hdnIdModificacion")).value == "modificar")
            {
                xhttp.send("caso=modificar&cadenaJson="+JSON.stringify(auto.ToJson()));
            }
            else
            {
                xhttp.send("caso=agregar&cadenaJson="+JSON.stringify(auto.ToJson()));
            }
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    let response:any = JSON.parse(xhttp.responseText);
                    if(response.TodoOK)
                        console.log("Agrego :)");
                    else
                        console.error("No agrego :(");
                        (<HTMLInputElement>document.getElementById("hdnIdModificacion")).value = "";
                        (<HTMLInputElement>document.getElementById("txtPatente")).readOnly = false;
                }
            };
        }

        public static Mostrar():void
        {
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            xhttp.send("caso=mostrar");
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    let listaJson = JSON.parse(xhttp.responseText);
                    let tabla:string = "<table border='1'><tr><td>PATENTE</td><td>MARCA</td><td>PRECIO</td><td>EDICION</td></tr>";
                    let i:number;
                    for(i=0;i<listaJson.length; i++)
                    {
                        console.log(listaJson[i]);
                        tabla += "<tr>";
                        tabla += ("<td>"+ listaJson[i]["patente"] +"</td>");
                        tabla += ("<td>"+ listaJson[i]["marca"] +"</td>");
                        tabla += ("<td>"+ listaJson[i]["precio"] +"</td>");
                        tabla += ("<td><input type='button' value='Eliminar' onclick='Enlace.Manejadora.EliminarAuto("+JSON.stringify(listaJson[i])+")'/>");
                        tabla += ("<input type='button' value='Modificar' onclick='Enlace.Manejadora.ModificarAuto("+JSON.stringify(listaJson[i])+")'/></td>");
                        tabla += "</tr>";
                    }
                    tabla += "</table>";
                    (<HTMLInputElement>document.getElementById("divTabla")).innerHTML = tabla;
                }
            };
        }

        public static EliminarAuto(aEliminar:JSON):void
        {
            console.log("Llego a func eliminar");
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            xhttp.send("caso=eliminar&cadenaJson="+JSON.stringify(aEliminar));
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    let response:any = JSON.parse(xhttp.responseText);
                    if(response.TodoOK)
                        console.log("Elimino :)");
                    else
                        console.error("No elimino :(");
                }
            };
            Enlace.Manejadora.Mostrar();
        }
        public static ModificarAuto(aModificar:any):void
        {
            (<HTMLInputElement>document.getElementById("txtPatente")).value = aModificar.patente;
            (<HTMLInputElement>document.getElementById("txtPatente")).readOnly = true;
            (<HTMLInputElement>document.getElementById("cboMarca")).value = aModificar.marca;
            (<HTMLInputElement>document.getElementById("txtPrecio")).value = aModificar.precio;
            (<HTMLInputElement>document.getElementById("hdnIdModificacion")).value = "modificar";
            
           
        }




    }
}