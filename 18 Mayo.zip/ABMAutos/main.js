"use strict";
/// <reference path="Auto.ts"/>
var auto = new Clases.Auto("aaa123", "Ford", 100000);
console.log(JSON.stringify(auto.ToJson()));
