var Clases;
(function (Clases) {
    var Auto = /** @class */ (function () {
        function Auto(patente, marca, precio) {
            this._marca = marca;
            this._patente = patente;
            this._precio = precio;
        }
        Auto.prototype.ToJson = function () {
            var string = '{"patente":"' + this._patente + '","marca":"' + this._marca + '","precio":' + this._precio + "}";
            return JSON.parse(string);
        };
        Auto.prototype.GetPrecioConIva = function () {
            return this._precio += this._precio * 1.21;
        };
        return Auto;
    }());
    Clases.Auto = Auto;
})(Clases || (Clases = {}));
var Enlace;
(function (Enlace) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.Agregar = function () {
            var patente = document.getElementById("txtPatente").value;
            var marca = document.getElementById("cboMarca").value;
            var precio = document.getElementById("txtPrecio").value;
            var auto = new Clases.Auto(patente, marca, precio);
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            if (document.getElementById("hdnIdModificacion").value == "modificar") {
                xhttp.send("caso=modificar&cadenaJson=" + JSON.stringify(auto.ToJson()));
            }
            else {
                xhttp.send("caso=agregar&cadenaJson=" + JSON.stringify(auto.ToJson()));
            }
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    var response = JSON.parse(xhttp.responseText);
                    if (response.TodoOK)
                        console.log("Agrego :)");
                    else
                        console.error("No agrego :(");
                    document.getElementById("hdnIdModificacion").value = "";
                    document.getElementById("txtPatente").readOnly = false;
                }
            };
        };
        Manejadora.Mostrar = function () {
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=mostrar");
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    var listaJson = JSON.parse(xhttp.responseText);
                    var tabla = "<table border='1'><tr><td>PATENTE</td><td>MARCA</td><td>PRECIO</td><td>EDICION</td></tr>";
                    var i = void 0;
                    for (i = 0; i < listaJson.length; i++) {
                        console.log(listaJson[i]);
                        tabla += "<tr>";
                        tabla += ("<td>" + listaJson[i]["patente"] + "</td>");
                        tabla += ("<td>" + listaJson[i]["marca"] + "</td>");
                        tabla += ("<td>" + listaJson[i]["precio"] + "</td>");
                        tabla += ("<td><input type='button' value='Eliminar' onclick='Enlace.Manejadora.EliminarAuto(" + JSON.stringify(listaJson[i]) + ")'/>");
                        tabla += ("<input type='button' value='Modificar' onclick='Enlace.Manejadora.ModificarAuto(" + JSON.stringify(listaJson[i]) + ")'/></td>");
                        tabla += "</tr>";
                    }
                    tabla += "</table>";
                    document.getElementById("divTabla").innerHTML = tabla;
                }
            };
        };
        Manejadora.EliminarAuto = function (aEliminar) {
            console.log("Llego a func eliminar");
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=eliminar&cadenaJson=" + JSON.stringify(aEliminar));
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    var response = JSON.parse(xhttp.responseText);
                    if (response.TodoOK)
                        console.log("Elimino :)");
                    else
                        console.error("No elimino :(");
                }
            };
            Enlace.Manejadora.Mostrar();
        };
        Manejadora.ModificarAuto = function (aModificar) {
            document.getElementById("txtPatente").value = aModificar.patente;
            document.getElementById("txtPatente").readOnly = true;
            document.getElementById("cboMarca").value = aModificar.marca;
            document.getElementById("txtPrecio").value = aModificar.precio;
            document.getElementById("hdnIdModificacion").value = "modificar";
        };
        return Manejadora;
    }());
    Enlace.Manejadora = Manejadora;
})(Enlace || (Enlace = {}));
