namespace Interfaces
{
    export interface Itributable
    {
        GetPrecioConIva():number;
    }
}