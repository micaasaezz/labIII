function Enviar() :void
{
    let usuario:string = (<HTMLInputElement>document.getElementById("txtUsuario")).value;
    let clave:string = (<HTMLInputElement>document.getElementById("txtClave")).value;
    let json = {"usuario":usuario,"clave":clave };
    let xhttp : XMLHttpRequest = new XMLHttpRequest();
    xhttp.open("POST", "../BACKEND/administrar.php/test", true);
    xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
    xhttp.send(JSON.stringify(json));
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) 
        {
            let response:any = xhttp.responseText;
            console.log(response);
            if(typeof(Storage) != undefined)
            {
                localStorage.setItem("miToken", response);
                console.log("Guardado!");
                
            }

        }
    };
}