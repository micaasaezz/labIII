window.onload = function Load(){
    var token = localStorage.getItem("miToken");

    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", "../BACKEND/administrar.php/test", true);
    xhttp.setRequestHeader("miToken",token);
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) 
        {
            var resultado = xhttp.responseText;
            console.log(resultado);
            var tablastring = "<table class=table-bordered>";
            
        }
    };
    
            
            
};
    
