function Enviar() {
    var usuario = document.getElementById("txtUsuario").value;
    var clave = document.getElementById("txtClave").value;
    var json = { "usuario": usuario, "clave": clave };
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", "../BACKEND/administrar.php/test", true);
    xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    xhttp.send(JSON.stringify(json));
    xhttp.onreadystatechange = function () {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            var response = xhttp.responseText;
            console.log(response);
            if (typeof (Storage) != undefined) {
                localStorage.setItem("miToken", response);
                console.log("Guardado!");
            }
        }
    };
}
