<?php
    
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require_once '/vendor/autoload.php';
    require "/clases/cd.php";
    use \Firebase\JWT\JWT as JWT;

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;
  
    $app = new \Slim\App(["settings" => $config]);

    $app->group('/test', function ()
    {
        $this->post('[/]', function ($request, $response) {
            $datos = $request->getParsedbody();

            $usuario = $datos["usuario"];
            $clave = $datos["clave"];     

            $objetoAccesoDato = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', "root", "");
            $consulta = $objetoAccesoDato->prepare("SELECT * from usuarios where usuario=:usuario and clave=:clave");
            $consulta->bindValue(':usuario',$usuario, PDO::PARAM_STR);
            $consulta->bindValue(':clave',$clave, PDO::PARAM_STR);
            if($consulta->execute()>0)
            {
                return "Registrado!";
            }
            else
            {
                $payload = array(
                "usuario" => $usuario,
                "clave" => $clave
                );
                $token = JWT::encode($payload,"miClaveSecreta");
                return $response->withJson($token, 200);
            }

            
        });
        /*$this->get('[/]', function ($request, $response, $args) {
            //$datos = $request->getParsedbody();
            $datos = $_GET;
            $token = $datos["token"];
            if(empty($token) || $token === "")
            {
                throw new Exception("El token esta vacio!");
            }

            try{
                $decodificado = JWT::decode(
                    $token,
                    "miClaveSecreta",
                    ["HS256"]
                );
            }
            catch(Exception $e){
                throw new Exception("Token no valido!!");
            }
            
            return "Todo OK!";

        });*/
        /*$this->post('[/]', function ($request, $response) {
            $datos = $request->getParsedbody();
            $token = $datos["token"];
            $titulo = $datos["titulo"];
            $cantante = $datos["cantante"];
            $anio = $datos["anio"];
            if(empty($token) || $token === "")
            {
                throw new Exception("El token esta vacio!");
            }

            try{
                $decodificado = JWT::decode(
                    $token,
                    "miClaveSecreta",
                    ["HS256"]
                );
                $objetoAccesoDato = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', "root", "");
                $consulta = $objetoAccesoDato->prepare("INSERT into cds (titel,interpret,jahr)values('$titulo','$cantante','$anio')");
                if($consulta->execute()>0)
                {
                    return "Elemento insertado";
                }
            }
            catch(Exception $e){
                throw new Exception("Token no valido!!");
            }
            

            
        });*/
        $this->get('[/]', function ($request, $response) {
            $token = $request->getHeader("token");
            if(empty($token) || $token === "")
            {
                throw new Exception("El token esta vacio!");
            }

            try{
                $decodificado = JWT::decode(
                    $token,
                    "miClaveSecreta",
                    ["HS256"]
                );
                $objetoAccesoDato = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', "root", "");
                $consulta = $objetoAccesoDato->prepare("SELECT * FROM cds");
                if($consulta->execute()>0)
                {
                    //return $consulta->fecthAll();
                    
                    //crear clase cd y metodo traer todos los cds
                    $cd=new cd();
                    $todo=cd::TraerTodoLosCds();
                    return $response->withJson($todo, 200);
                }
            }
            catch(Exception $e){
                throw new Exception("Token no valido!!");
            }
            
            
            

        });

    });
    $app->run();
?>