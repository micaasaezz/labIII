<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";

use Firebase\JWT\JWT as JWT;

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);

$app->post('[/]', function ($request, $response) 
{
    $datos = $request->getParsedBody();
    $extension = pathinfo($_FILES["foto"]["name"],PATHINFO_EXTENSION);
    $respuesta = array("respuesta"=> "");
    if($extension != "jpg" || $extension != "png")
    {
        $respuesta["respuesta"] = "error";
    }
    else
    {
        $nombre = $datos["legajo"].".".$extension;
        move_uploaded_file($_FILES["foto"]["tmp_name"],"../frontend/fotos/".$nombre);   
        $respuesta["respuesta"] = $nombre;
    }

    return $response->withJson($respuesta,200);  
});

$app->group('/token', function ()
{
    $this->post('[/]', function ($request, $response) 
    {
        $datos = $request->getParsedBody();
        $array = array(
            "correo"=>$datos["correo"],
            "nombre"=>$datos["nombre"],
            "apellido"=>$datos["apellido"],  
            "perfil"=>$datos["perfil"], 
            "exp"=>time()+15,
            "iat"=>time()
        );
        $token=JWT::encode($array,"clave");
        return $response->withJson($token,200);
    });
});

$app->get('[/]', function ($request, $response) 
{
    $token = ($request->getHeader("token")[0]);
        try
        {
            $todo= JWT::decode($token,"clave",["HS256"]);
            
            return $response->withJson($todo->perfil,200);
        }
        catch(Exception $e)
        {
            return $response->withJson("error",200);

        }
    return $response->withJson($token,200);
    
});




$app->run();

?>