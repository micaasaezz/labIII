/// <reference path="node_modules/@types/jquery/index.d.ts" />
var Enlace;
(function (Enlace) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.CargarArray = function () {
            var array = [
                { "correo": "jorge@gmail.com", "clave": "jorge1", "nombre": "jorge", "apellido": "lopez", "legajo": 111, "perfil": "admin", "foto": "111.jpg" },
                { "correo": "marta@gmail.com", "clave": "marta1", "nombre": "marta", "apellido": "perez", "legajo": 222, "perfil": "superadmin", "foto": "222.jpg" },
                { "correo": "maria@gmail.com", "clave": "maria1", "nombre": "maria", "apellido": "sanchez", "legajo": 333, "perfil": "usuario", "foto": "333.jpg" },
                { "correo": "roberto@gmail.com", "clave": "roberto1", "nombre": "roberto", "apellido": "gonzalez", "legajo": 444, "perfil": "admin", "foto": "444.jpg" },
                { "correo": "juan@gmail.com", "clave": "juan1", "nombre": "juan", "apellido": "rodriguez", "legajo": 555, "perfil": "usuario", "foto": "555.jpg" },
            ];
            if (localStorage.getItem("miArray")) {
                console.log("El array ya existe! ");
                console.log(localStorage.getItem("miArray"));
            }
            else {
                localStorage.setItem("miArray", JSON.stringify(array));
                console.log(JSON.stringify(array));
            }
        };
        Manejadora.Enviar = function () {
            var mail = $("#email").val();
            var clave = $("#clave").val();
            $("#divError").html("");
            Enlace.Manejadora.AdministrarSpanError("spanClave", false);
            Enlace.Manejadora.AdministrarSpanError("spanMail", false);
            if (mail == "" && clave == "") {
                Enlace.Manejadora.AdministrarSpanError("spanMail", true);
                document.getElementById("divError").style.display = "block";
                $("#divError").html("Faltan completar datos");
                Enlace.Manejadora.AdministrarSpanError("spanClave", true);
                console.log("faltan los 2");
            }
            else if (mail == "") {
                Enlace.Manejadora.AdministrarSpanError("spanMail", true);
                document.getElementById("divError").style.display = "block";
                $("#divError").html("El mail no puede estar vacio!");
                console.log("falta mail");
            }
            else if (clave == "") {
                Enlace.Manejadora.AdministrarSpanError("spanClave", true);
                document.getElementById("divError").style.display = "block";
                $("#divError").html("La clave no puede estar vacia!");
                console.log("falta clave");
            }
            else {
                console.log("estan los 2");
                var array = localStorage.getItem("miArray");
                var encontro = false;
                array = JSON.parse(array);
                for (var i = 0; i < array.length; i++) {
                    if (array[i]["correo"] == mail && array[i]["clave"] == clave) {
                        encontro = true;
                        var formData = new FormData();
                        formData.append("correo", mail);
                        formData.append("nombre", array[i]["nombre"]);
                        formData.append("apellido", array[i]["apellido"]);
                        formData.append("perfil", array[i]["perfil"]);
                        $.ajax({
                            type: 'POST',
                            url: "../backend/index.php/token",
                            dataType: "json",
                            data: formData,
                            async: true,
                            contentType: false,
                            processData: false
                        })
                            .done(function (resultado) {
                            localStorage.setItem("mitoken", resultado);
                            location.href = "principal.html";
                            console.log(resultado);
                        })
                            .fail(function (jqXHR, textStatus, errorThrown) {
                            console.error(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
                            $("#divError").html("No registrado!");
                        });
                        break;
                    }
                }
                if (!encontro) {
                    document.getElementById("divError").style.display = "block";
                    $("#divError").html("No registrado!");
                }
            }
        };
        Manejadora.AdministrarSpanError = function (id, ocultar) {
            if (!ocultar)
                document.getElementById(id).style.display = "none";
            else
                document.getElementById(id).style.display = "block";
        };
        return Manejadora;
    }());
    Enlace.Manejadora = Manejadora;
})(Enlace || (Enlace = {}));
