/// <reference path="node_modules/@types/jquery/index.d.ts" />
var Enlace;
(function (Enlace) {
    var Registro = /** @class */ (function () {
        function Registro() {
        }
        Registro.Enviar = function () {
            var mail = $("#mail").val();
            var clave = $("#clave").val();
            var nombre = $("#nombre").val();
            var apellido = $("#apellido").val();
            var confirmar = $("#confirmar").val();
            var foto = $("#foto").val();
            var perfil = $("#cmbPerfil").val();
            var legajo = $("#legajo").val();
            $("#divError").html("");
            Enlace.Registro.AdministrarSpanTodos(false);
            var faltanDatos = false;
            var mensajeError = "";
            if (nombre == "") {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanNombre", true);
            }
            else if (nombre.length > 15) {
                Enlace.Registro.AdministrarSpanError("spanNombre", true);
                faltanDatos = true;
                mensajeError += "Nombre muy largo!<br>";
            }
            if (apellido == "") {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanApellido", true);
            }
            else if (apellido.length > 10) {
                Enlace.Registro.AdministrarSpanError("spanApellido", true);
                faltanDatos = true;
                mensajeError += "Apellido muy largo!<br>";
            }
            if (clave == "") {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanClave", true);
            }
            else if (clave.length > 8 || clave.length < 4) {
                document.getElementById("spanClave").style.display = "block";
                mensajeError += "Clave rango invalido!<br>";
                faltanDatos = true;
            }
            if (confirmar == "") {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanConfirmar", true);
            }
            else if (clave.length > 8 || clave.length < 4) {
                document.getElementById("spanConfirmar").style.display = "block";
                mensajeError += "Clave rango invalido!<br>";
                faltanDatos = true;
            }
            if (foto == "") {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanFoto", true);
            }
            if (legajo == "") {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanLegajo", true);
            }
            if (mail == "") {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanMail", true);
            }
            else {
                var emailRegex = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
                if (!emailRegex.test(mail)) {
                    Enlace.Registro.AdministrarSpanError("spanMail", true);
                    faltanDatos = true;
                    mensajeError += "Formato del mail erroneo!<br>";
                }
            }
            if (!faltanDatos) {
                if (confirmar == clave) {
                    var array_1 = localStorage.getItem("miArray");
                    array_1 = JSON.parse(array_1);
                    var encontroMail = false;
                    var encontroLegajo = false;
                    for (var i = 0; i < array_1.length; i++) {
                        if (array_1[i]["correo"] == mail) {
                            encontroMail = true;
                            break;
                        }
                        if (array_1[i]["legajo"] == legajo) {
                            encontroLegajo = true;
                            break;
                        }
                    }
                    if (encontroMail) {
                        document.getElementById("divError").style.display = "block";
                        $("#divError").html("Mail ya registrado!");
                        Enlace.Registro.AdministrarSpanError("spanMail", true);
                    }
                    else if (encontroLegajo) {
                        document.getElementById("divError").style.display = "block";
                        $("#divError").html("Legajo ya registrado!");
                        Enlace.Registro.AdministrarSpanError("spanLegajo", true);
                    }
                    else {
                        var form = new FormData();
                        form.append("foto", foto.files);
                        form.append("legajo", legajo);
                        $.ajax({
                            type: 'POST',
                            url: "../backend/",
                            dataType: "json",
                            data: form,
                            contentType: false,
                            processData: false
                        })
                            .done(function (rta) {
                            var json = JSON.parse(rta);
                            if (json["respuesta"] != "error") {
                                foto = json["respuesta"];
                                console.log(foto);
                                var usNuevo = JSON.parse('{"correo":"' + mail + '","clave":"' + clave + '","nombre":"' + nombre + '","apellido":"' + apellido + '","legajo":' + legajo + ',"perfil":"' + perfil + '","foto":"' + foto + '"}');
                                array_1.push(usNuevo);
                                localStorage.setItem("miArray", JSON.stringify(array_1));
                                location.href = "principal.html";
                            }
                            else {
                                mensajeError += "Foto con extension invalida solo JPG y PNG!<br>";
                                mensajeError += "No se guardo la foto!<br>";
                                document.getElementById("divError").style.display = "block";
                                $("#divError").html(mensajeError);
                            }
                        })
                            .fail(function (aaa) {
                            console.log(aaa);
                        });
                    }
                }
                else {
                    document.getElementById("divError").style.display = "block";
                    $("#divError").html("Las claves no coinciden!");
                    Enlace.Registro.AdministrarSpanError("spanConfirmar", true);
                }
            }
            else {
                document.getElementById("divError").style.display = "block";
                if (mensajeError == "") {
                    mensajeError += "Faltan datos!<br>";
                }
                $("#divError").html(mensajeError);
            }
        };
        Registro.AdministrarSpanError = function (id, ocultar) {
            if (!ocultar)
                document.getElementById(id).style.display = "none";
            else
                document.getElementById(id).style.display = "block";
        };
        Registro.AdministrarSpanTodos = function (ocultar) {
            Enlace.Registro.AdministrarSpanError("spanNombre", ocultar);
            Enlace.Registro.AdministrarSpanError("spanApellido", ocultar);
            Enlace.Registro.AdministrarSpanError("spanClave", ocultar);
            Enlace.Registro.AdministrarSpanError("spanConfirmar", ocultar);
            Enlace.Registro.AdministrarSpanError("spanFoto", ocultar);
            Enlace.Registro.AdministrarSpanError("spanPerfil", ocultar);
            Enlace.Registro.AdministrarSpanError("spanLegajo", ocultar);
            Enlace.Registro.AdministrarSpanError("spanMail", ocultar);
        };
        return Registro;
    }());
    Enlace.Registro = Registro;
})(Enlace || (Enlace = {}));
