/// <reference path="node_modules/@types/jquery/index.d.ts" />
namespace Enlace{
    export class Registro
    {
        public static Enviar():void
        {
            let mail: string = <string> $("#mail").val(); 
            let clave: string = <string> $("#clave").val(); 
            let nombre: string = <string> $("#nombre").val(); 
            let apellido: string = <string> $("#apellido").val(); 
            let confirmar: string = <string> $("#confirmar").val(); 
            let foto: any = $("#foto").val(); 
            let perfil: string = <string> $("#cmbPerfil").val(); 
            let legajo: string = <string> $("#legajo").val(); 

            $("#divError").html("");
            Enlace.Registro.AdministrarSpanTodos(false);
            
            let faltanDatos:boolean = false;
            let mensajeError:string = "";

            if(nombre=="")
            {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanNombre", true); 
            }
            else if(nombre.length>15)
            {
                Enlace.Registro.AdministrarSpanError("spanNombre", true); 
                faltanDatos = true;
                mensajeError += "Nombre muy largo!<br>";
            }

            if(apellido=="")
            {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanApellido", true);
            }
            else if(apellido.length>10)
            {
                Enlace.Registro.AdministrarSpanError("spanApellido", true); 
                faltanDatos = true;
                mensajeError += "Apellido muy largo!<br>";
            }

            if(clave=="")
            {
                faltanDatos = true
                Enlace.Registro.AdministrarSpanError("spanClave", true);
            }
            else if(clave.length>8||clave.length<4)
            {
                (<HTMLSpanElement>document.getElementById("spanClave")).style.display="block";
                mensajeError += "Clave rango invalido!<br>";
                faltanDatos = true;
            }

            if(confirmar=="")
            {
                faltanDatos = true
                Enlace.Registro.AdministrarSpanError("spanConfirmar", true);
            }
            else if(clave.length>8||clave.length<4)
            {
                (<HTMLSpanElement>document.getElementById("spanConfirmar")).style.display="block";
                mensajeError += "Clave rango invalido!<br>";
                faltanDatos = true;
            }

            if(foto=="")
            {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanFoto", true);
            }         


            if(legajo=="")
            {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanLegajo", true);
            }

            if(mail=="")
            {
                faltanDatos = true;
                Enlace.Registro.AdministrarSpanError("spanMail", true);
            }
            else
            {
                let emailRegex:any = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
            
                if (!emailRegex.test(mail)) 
                {
                    Enlace.Registro.AdministrarSpanError("spanMail", true);
                    faltanDatos = true;
                    mensajeError += "Formato del mail erroneo!<br>";
                }
            }

            if(!faltanDatos)
            {
                if(confirmar == clave)
                {
                    let array: any = localStorage.getItem("miArray");
                    array = JSON.parse(array);
                    let encontroMail:boolean = false;
                    let encontroLegajo:boolean = false;
                    for(let i=0; i<array.length;i++)
                    {
                        if(array[i]["correo"] == mail)
                        {
                            encontroMail = true;
                            break;
                        }
                        if(array[i]["legajo"] == legajo)
                        {
                            encontroLegajo = true;
                            break;
                        }
                    }
                    if(encontroMail)
                    {
                        (<HTMLSpanElement> document.getElementById("divError")).style.display = "block";
                        $("#divError").html("Mail ya registrado!");
                        Enlace.Registro.AdministrarSpanError("spanMail", true);
                    }
                    else if(encontroLegajo)
                    {
                        (<HTMLSpanElement> document.getElementById("divError")).style.display = "block";
                        $("#divError").html("Legajo ya registrado!");
                        Enlace.Registro.AdministrarSpanError("spanLegajo", true);
                    }
                    else
                    {
                        let form:FormData=new FormData();
                        form.append("foto",foto.files);
                        form.append("legajo", legajo);
                        $.ajax({
                            type: 'POST',
                            url: "../backend/",
                            dataType:"json",
                            data:form,
                            contentType: false,
                            processData: false,
                        })
                        .done(function (rta){
                            let json = JSON.parse(rta);
                            if(json["respuesta"] != "error")
                            {
                                foto = json["respuesta"];
                                console.log(foto);
                                let usNuevo = JSON.parse('{"correo":"'+mail+'","clave":"'+clave+'","nombre":"'+nombre+'","apellido":"'+apellido+'","legajo":'+legajo+',"perfil":"'+perfil+'","foto":"'+foto+'"}');
                                array.push(usNuevo);
                                localStorage.setItem("miArray", JSON.stringify(array));
                                location.href ="principal.html";
                            }
                            else
                            {
                                mensajeError += "Foto con extension invalida solo JPG y PNG!<br>";
                                mensajeError += "No se guardo la foto!<br>";
                                (<HTMLSpanElement> document.getElementById("divError")).style.display = "block";
                                $("#divError").html(mensajeError);
                            }
                        })
                        .fail(function(aaa){
                            console.log(aaa);
                        });
                    }
                }
                else
                {
                    (<HTMLSpanElement> document.getElementById("divError")).style.display = "block";
                    $("#divError").html("Las claves no coinciden!");
                    Enlace.Registro.AdministrarSpanError("spanConfirmar", true);
                }
    
            }
            else
            {
                (<HTMLSpanElement> document.getElementById("divError")).style.display = "block";
                if(mensajeError=="")
                {
                    mensajeError += "Faltan datos!<br>";
                }
                $("#divError").html(mensajeError);
            }
            

        }

        public static AdministrarSpanError(id:string, ocultar:boolean)
        {
            if(!ocultar)
                (<HTMLSpanElement> document.getElementById(id)).style.display = "none"; 
            else
                (<HTMLSpanElement> document.getElementById(id)).style.display = "block";
        }
        public static AdministrarSpanTodos(ocultar:boolean)
        {
                Enlace.Registro.AdministrarSpanError("spanNombre", ocultar); 
                Enlace.Registro.AdministrarSpanError("spanApellido", ocultar);
                Enlace.Registro.AdministrarSpanError("spanClave", ocultar);
                Enlace.Registro.AdministrarSpanError("spanConfirmar", ocultar);
                Enlace.Registro.AdministrarSpanError("spanFoto", ocultar);
                Enlace.Registro.AdministrarSpanError("spanPerfil", ocultar);
                Enlace.Registro.AdministrarSpanError("spanLegajo", ocultar);
                Enlace.Registro.AdministrarSpanError("spanMail", ocultar);
        }
        
    }
}