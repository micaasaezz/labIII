/// <reference path="node_modules/@types/jquery/index.d.ts" />
namespace Enlace{
    export class Listado
    {
        public static Cargar():void
        {
            let token: any = localStorage.getItem("mitoken");
            
            let arrayJson:any=localStorage.getItem("miArray");
            
            let json:any=JSON.parse(arrayJson);

            $("#tablaListado").html("");
    
            $.ajax({
                type: 'get',
                url: "../BACKEND/",
                dataType:"json",
                contentType: false,
                processData: false,
                headers:{"token":token}
            })
            .done(function (objJson) {
    
                if(objJson=="error")
                {
                    location.href="login.html";
                }
                console.log(objJson);
                if(objJson=="admin")
                {
                    let lista:string='<table class="table"><thead><tr><th scope="col">CORREO</th><th scope="col">NOMBRE</th><th scope="col">APELLIDO</th><th scope="col">PERFIL</th><th colspan="" scope="col">LEGAJO</th><th  scope="col">FOTO</th> <th  scope="col">BORRAR</th></tr></thead><tbody>';
                    for (let i = 0; i < json.length; i++) 
                    {
                        lista+='<tr><td><input id="'+i+'"name="'+i+'titulo" type="text" class="form-control" value="'+json[i].correo+'" readonly></td><td><input id="'+i+'empresa" type="text" class="form-control" name="'+i+'empresa" value="'+json[i].nombre+'"></td><td><input id="'+i+'genero" type="text" class="form-control" name="'+i+'genero" value="'+json[i].apellido+'"></td><td><input type=""class="form-control" name="'+i+'precio"id="'+i+'precio" value="'+json[i].perfil+'"></td><td><input id="'+i+'genero" type="text" class="form-control" name="'+i+'genero" value="'+json[i].legajo+'"></td><td><img src="fotos/'+json[i].foto+'" width="50px" height="50px"></td><td><a class="btn btn-danger" onclick="Manejador.borrar('+i+')" role="button">Borrar</a></td></tr>';
                    }
                    $("#tablaListado").html(lista+'</tbody></table>');
                }
                else
                {
                    let lista:string='<table class="table"><thead><tr><th scope="col">Mail</th><th scope="col">NOMBRE</th><th scope="col">APELLIDO</th><th scope="col">PERFIL</th><th colspan="" scope="col">LEGAJO</th><th  scope="col">FOTO</th></tr></thead><tbody>';
                    for (let i = 0; i < json.length; i++) 
                    {
                        lista+='<tr><td><input id="'+i+'"name="'+i+'titulo" type="text" class="form-control" value="'+json[i].correo+'" readonly></td><td><input id="'+i+'empresa" type="text" class="form-control" name="'+i+'empresa" value="'+json[i].nombre+'"></td><td><input id="'+i+'genero" type="text" class="form-control" name="'+i+'genero" value="'+json[i].apellido+'"></td><td><input type=""class="form-control" name="'+i+'precio"id="'+i+'precio" value="'+json[i].perfil+'"></td><td><input id="'+i+'genero" type="text" class="form-control" name="'+i+'genero" value="'+json[i].legajo+'"></td><td><img src="'+json[i].foto+'" width="50px" height="50px"></td></tr>';
                    }
    
                    $("#tablaListado").html(lista+'</tbody></table>');
                }
            })
            .fail(function(aaa){
                console.log(JSON.stringify(aaa));
                
            });
        }
        public static Borrar(legajo:string):void
        {
            let array: any = localStorage.getItem("miArray");
            console.log(JSON.parse(array));

            for (let i = 0; i < array.length; i++) 
            {
                if(array[i].legajo == legajo)    
                {
                    array.splice(i, 1);
                    location.href="principal.html";   
                }
            }

        }
        

    }
} 