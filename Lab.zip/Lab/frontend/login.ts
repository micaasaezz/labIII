/// <reference path="node_modules/@types/jquery/index.d.ts" />
namespace Enlace{
    export class Manejadora
    {
        public static CargarArray():void
        {
            let array: any[] = [
                {"correo":"jorge@gmail.com", "clave":"jorge1", "nombre":"jorge", "apellido":"lopez", "legajo":111, "perfil":"admin", "foto":"111.jpg"},
                {"correo":"marta@gmail.com", "clave":"marta1", "nombre":"marta", "apellido":"perez", "legajo":222, "perfil":"superadmin", "foto":"222.jpg"},
                {"correo":"maria@gmail.com", "clave":"maria1", "nombre":"maria", "apellido":"sanchez", "legajo":333, "perfil":"usuario", "foto":"333.jpg"},
                {"correo":"roberto@gmail.com", "clave":"roberto1", "nombre":"roberto", "apellido":"gonzalez", "legajo":444, "perfil":"admin", "foto":"444.jpg"},
                {"correo":"juan@gmail.com", "clave":"juan1", "nombre":"juan", "apellido":"rodriguez", "legajo":555, "perfil":"usuario", "foto":"555.jpg"},
            ];
            if(localStorage.getItem("miArray"))
            {
                console.log("El array ya existe! ");
                console.log(localStorage.getItem("miArray")); 
            }
            else
            {
                localStorage.setItem("miArray", JSON.stringify(array));
                console.log(JSON.stringify(array));    
            }
                
        }
        public static Enviar():void
        {
            let mail: string = <string> $("#email").val(); 
            let clave: string = <string> $("#clave").val(); 
            $("#divError").html("");
            Enlace.Manejadora.AdministrarSpanError("spanClave", false); 
            Enlace.Manejadora.AdministrarSpanError("spanMail", false);  
            if(mail=="" && clave=="")
            {
                Enlace.Manejadora.AdministrarSpanError("spanMail", true);
                (<HTMLSpanElement> document.getElementById("divError")).style.display = "block";
                $("#divError").html("Faltan completar datos");
                Enlace.Manejadora.AdministrarSpanError("spanClave", true);
                console.log("faltan los 2");
            }
            else if(mail=="")
            {
                Enlace.Manejadora.AdministrarSpanError("spanMail", true);
                (<HTMLSpanElement> document.getElementById("divError")).style.display = "block";
                $("#divError").html("El mail no puede estar vacio!");
                console.log("falta mail");
            }
            else if(clave=="")
            {
                Enlace.Manejadora.AdministrarSpanError("spanClave", true);  
                (<HTMLSpanElement> document.getElementById("divError")).style.display = "block";  
                $("#divError").html("La clave no puede estar vacia!");
                console.log("falta clave");
            }
            else
            {
                console.log("estan los 2");
                let array: any = localStorage.getItem("miArray");
                let encontro:boolean = false;
                array = JSON.parse(array);
                for(let i=0; i<array.length;i++)
                {
                    if(array[i]["correo"] == mail && array[i]["clave"] == clave)
                    {
                        encontro = true;
                        var formData:FormData = new FormData();
                        formData.append("correo",  mail);
                        formData.append("nombre", array[i]["nombre"]);
                        formData.append("apellido", array[i]["apellido"]);
                        formData.append("perfil", array[i]["perfil"]);
                        $.ajax({
                            type: 'POST',
                            url: "../backend/index.php/token",
                            dataType: "json",
                            data: formData,
                            async: true,
                            contentType: false,
                            processData: false
                        })
                        .done(function (resultado) {
                            localStorage.setItem("mitoken",resultado);
                            location.href ="principal.html";
                            console.log(resultado);
                        })
                        .fail(function (jqXHR, textStatus, errorThrown) {
                            console.error(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
                            $("#divError").html("No registrado!");
                        });
                        break;
                    }
                }
                    
                if(!encontro)
                {
                    (<HTMLSpanElement> document.getElementById("divError")).style.display = "block"; 
                    $("#divError").html("No registrado!");
                }
            }
        }
        public static AdministrarSpanError(id:string, ocultar:boolean)
        {
            if(!ocultar)
                (<HTMLSpanElement> document.getElementById(id)).style.display = "none"; 
            else
                (<HTMLSpanElement> document.getElementById(id)).style.display = "block";
        }

    }
} 