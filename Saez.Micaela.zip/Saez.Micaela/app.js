var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Entidades;
(function (Entidades) {
    var Persona = /** @class */ (function () {
        function Persona(nombre, apellido, edad) {
            this._apellido = apellido;
            this._edad = edad;
            this._nombre = nombre;
        }
        Persona.prototype.PersonaToString = function () {
            return '"nombre:"' + this._nombre + '",apellido:"' + this._apellido + '",edad:"' + this._edad;
        };
        return Persona;
    }());
    Entidades.Persona = Persona;
})(Entidades || (Entidades = {}));
var Entidades;
(function (Entidades) {
    var Ciudadano = /** @class */ (function (_super) {
        __extends(Ciudadano, _super);
        function Ciudadano(nombre, apellido, edad, dni, pais) {
            var _this = _super.call(this, nombre, apellido, edad) || this;
            _this._dni = dni;
            _this._pais = pais;
            return _this;
        }
        Ciudadano.prototype.CiudadanoToJSON = function () {
            return "{" + _super.prototype.PersonaToString.call(this) + '",pais:"' + this._pais + '",dni:"' + this._dni + "}";
        };
        return Ciudadano;
    }(Entidades.Persona));
    Entidades.Ciudadano = Ciudadano;
})(Entidades || (Entidades = {}));
var Test;
(function (Test) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.prototype.AgregarCiudadanos = function () {
            var _this = this;
            this.LimpiarForm();
            var nombre = document.getElementById("txtNombre").value;
            var apellido = document.getElementById("txtApellido").value;
            var dni = document.getElementById("txtDni").value;
            var edad = document.getElementById("txtEdad").value;
            var pais = document.getElementById("cboPais").value;
            var ciudadano = new Entidades.Ciudadano(nombre, apellido, edad, dni, pais);
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=agregar&cadenaJson=" + ciudadano.CiudadanoToJSON());
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    _this.AdministrarSpinner(false);
                    console.log(xhttp.responseText);
                    _this.MostrarCiudadanos();
                }
            };
        };
        Manejadora.prototype.MostrarCiudadanos = function () {
            var _this = this;
            this.LimpiarForm();
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=mostrar");
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    _this.AdministrarSpinner(false);
                    var listaJson = xhttp.responseText;
                    var tabla = "<table>";
                    listaJson = JSON.stringify(listaJson);
                    var i = void 0;
                    for (i = 0; i < listaJson.length; i++) {
                        tabla += "<tr>";
                        tabla += ("<td>" + listaJson[i]["nombre"] + "</td>");
                        tabla += ("<td>" + listaJson[i]["apellido"] + "</td>");
                        tabla += ("<td>" + listaJson[i]["edad"] + "</td>");
                        tabla += ("<td>" + listaJson[i]["pais"] + "</td>");
                        tabla += ("<td>" + listaJson[i]["dni"] + "</td>");
                        tabla += ("<td><input type='button' value='Modificar' onclick=ModificarCiudadano()/></td>");
                        tabla += ("<td><input type='button' value='Eliminar' onclick=EliminarCiudadano(" + listaJson[i] + ")/></td>");
                        tabla += "</tr>";
                    }
                    tabla += "</table>";
                    document.getElementById("divTabla").textContent = tabla;
                }
            };
        };
        Manejadora.prototype.EliminarCiudadano = function (aEliminar) {
            var _this = this;
            this.LimpiarForm();
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=eliminar&cadenaJson=" + aEliminar);
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    _this.AdministrarSpinner(false);
                    console.log(xhttp.responseText);
                    _this.MostrarCiudadanos();
                }
            };
        };
        Manejadora.prototype.ModificarCiudadano = function (aModificar) {
            var _this = this;
            this.LimpiarForm();
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=modificar&cadenaJson=" + aModificar);
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    _this.AdministrarSpinner(false);
                    console.log(xhttp.responseText);
                    _this.MostrarCiudadanos();
                }
            };
        };
        Manejadora.prototype.FiltrarCiudadanosPorPais = function () {
            var _this = this;
            this.LimpiarForm();
            var pais = document.getElementById("cboPais").value;
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=mostrar");
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    _this.AdministrarSpinner(false);
                    var listaJson = JSON.stringify(xhttp.responseText);
                    var i = void 0;
                    var lista = "";
                    for (i = 0; i < listaJson.length; i++) {
                        if (listaJson[i]["descripcion"] == pais) {
                            lista += (listaJson[i] + "\n");
                        }
                    }
                    document.getElementById("divTabla").textContent = lista;
                }
            };
        };
        Manejadora.prototype.CargarPaisesJSON = function () {
            var _this = this;
            this.LimpiarForm();
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=paises");
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    _this.AdministrarSpinner(false);
                    var paises = JSON.stringify(xhttp.responseText);
                    var i = void 0;
                    for (i = 0; i < paises.length; i++) {
                        document.getElementById("cboPais").appendChild(paises[i]["descripcion"]);
                    }
                }
            };
        };
        Manejadora.prototype.LimpiarForm = function () {
            document.getElementById("txtNombre").value = "";
            document.getElementById("txtApellido").value = "";
            document.getElementById("txtDni").value = "";
            document.getElementById("txtEdad").value = "";
            document.getElementById("cboPais").value = "Argentina";
        };
        Manejadora.prototype.AdministrarSpinner = function (mostrar) {
            if (mostrar) {
                document.getElementById("divSpinner").style.display = "none";
            }
            else {
                document.getElementById("divSpinner").style.display = "block";
            }
        };
        return Manejadora;
    }());
    Test.Manejadora = Manejadora;
})(Test || (Test = {}));
