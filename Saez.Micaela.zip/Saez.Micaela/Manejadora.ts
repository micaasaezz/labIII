namespace Test{
    
    export class Manejadora
    {
        public AgregarCiudadanos() 
        {
            this.LimpiarForm();
            let nombre: string = (<HTMLInputElement>document.getElementById("txtNombre")).value;
            let apellido: string = (<HTMLInputElement>document.getElementById("txtApellido")).value;
            let dni: string = (<HTMLInputElement>document.getElementById("txtDni")).value;
            let edad: string = (<HTMLInputElement>document.getElementById("txtEdad")).value;
            let pais: string = (<HTMLInputElement>document.getElementById("cboPais")).value;
        
            var ciudadano = new Entidades.Ciudadano(nombre,apellido,<number><any>edad,<number><any>dni,pais);

            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            xhttp.send("caso=agregar&cadenaJson="+ciudadano.CiudadanoToJSON());
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    this.AdministrarSpinner(false);                        
                    console.log(xhttp.responseText);
                    this.MostrarCiudadanos();
                }
            };
        }

        public MostrarCiudadanos()
        {
            this.LimpiarForm();
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            xhttp.send("caso=mostrar");
            this.AdministrarSpinner(true);         
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    this.AdministrarSpinner(false);
                    let listaJson = xhttp.responseText;
                    let tabla:string = "<table>";
                    listaJson = JSON.stringify(listaJson);
                    let i:number;
                    for(i=0;i<listaJson.length; i++)
                    {
                        tabla += "<tr>";
                        tabla += ("<td>"+listaJson[i]["nombre"]+"</td>");
                        tabla += ("<td>"+listaJson[i]["apellido"]+"</td>");
                        tabla += ("<td>"+listaJson[i]["edad"]+"</td>");
                        tabla += ("<td>"+listaJson[i]["pais"]+"</td>");
                        tabla += ("<td>"+listaJson[i]["dni"]+"</td>");     
                        
                        tabla += ("<td><input type='button' value='Modificar' onclick=ModificarCiudadano()/></td>");
                        tabla += ("<td><input type='button' value='Eliminar' onclick=EliminarCiudadano("+listaJson[i]+")/></td>");

                        tabla += "</tr>";
                    }
                    tabla += "</table>";
                    (<HTMLInputElement>document.getElementById("divTabla")).textContent = tabla;
                }
            };
        }
        public EliminarCiudadano(aEliminar:JSON)
        {
            this.LimpiarForm();
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            xhttp.send("caso=eliminar&cadenaJson="+aEliminar);
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    this.AdministrarSpinner(false);
                    console.log(xhttp.responseText);
                    this.MostrarCiudadanos();
                }
            };
        }
        public ModificarCiudadano(aModificar:JSON)
        {
            this.LimpiarForm();
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            xhttp.send("caso=modificar&cadenaJson="+aModificar);
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    this.AdministrarSpinner(false);
                    console.log(xhttp.responseText);
                    this.MostrarCiudadanos();
                }
            };
        }
        public FiltrarCiudadanosPorPais()
        {
            this.LimpiarForm();
            let pais: string = (<HTMLInputElement>document.getElementById("cboPais")).value;
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            xhttp.send("caso=mostrar");
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    this.AdministrarSpinner(false);
                    let listaJson = JSON.stringify(xhttp.responseText);
                    let i:number;
                    let lista:string="";
                    for(i=0;i<listaJson.length; i++)
                    {
                        if(listaJson[i]["descripcion"] == pais)
                        {
                            lista+=(listaJson[i]+"\n");
                        }
                       
                    }
                    (<HTMLInputElement>document.getElementById("divTabla")).textContent = lista;
                }
            };
        }
        public CargarPaisesJSON()
        {
            this.LimpiarForm();
            let xhttp : XMLHttpRequest = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
            xhttp.send("caso=paises");
            this.AdministrarSpinner(true);
            xhttp.onreadystatechange = () => {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    this.AdministrarSpinner(false);
                    let paises:string = JSON.stringify(xhttp.responseText);
                    let i:number;
                    for(i=0;i<paises.length; i++)
                    {
                        (<HTMLInputElement>document.getElementById("cboPais")).appendChild(paises[i]["descripcion"]);
                    }
                }
            };
        }
        public LimpiarForm()
        {
            (<HTMLInputElement>document.getElementById("txtNombre")).value = "";
            (<HTMLInputElement>document.getElementById("txtApellido")).value = "";
            (<HTMLInputElement>document.getElementById("txtDni")).value = "";
            (<HTMLInputElement>document.getElementById("txtEdad")).value = "";
            (<HTMLInputElement>document.getElementById("cboPais")).value = "Argentina";
        }
        public AdministrarSpinner(mostrar:boolean)
        {
            if(mostrar)
            {
                (<HTMLInputElement>document.getElementById("divSpinner")).style.display = "none";
            }
            else
            {
                (<HTMLInputElement>document.getElementById("divSpinner")).style.display = "block";
            }
        }
    }
}