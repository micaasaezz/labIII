namespace Entidades{

    export class Ciudadano extends Entidades.Persona
    {
        protected _dni : number;
        protected _pais : string;

        public constructor(nombre:string, apellido:string, edad:number, dni:number, pais:string)
        {
            super(nombre,apellido,edad);
            this._dni = dni;
            this._pais = pais;
        }

        public CiudadanoToJSON()
        {
            return "{"+super.PersonaToString()+'",pais:"'+this._pais+'",dni:"'+this._dni+"}";
        }
        

    }
}