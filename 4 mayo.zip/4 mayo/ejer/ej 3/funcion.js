"use strict";
/* EJ 3
    var producto = {"codigoBarra":123456789, "nombre":"chocolate", "precio":10};
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", "mostrarJson.php", true);
    xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
    xhttp.send("producto="+JSON.stringify(producto));
    xhttp.onreadystatechange = function () {
        console.log(xhttp.readyState);
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            alert(xhttp.responseText);
        }
    };
*/
var producto = [
    { "codigoBarra": 111111111, "nombre": "chocolate", "precio": 10 },
    { "codigoBarra": 222222222, "nombre": "pepas", "precio": 25 },
    { "codigoBarra": 333333333, "nombre": "gomitas", "precio": 15 }
];
var xhttp = new XMLHttpRequest();
xhttp.open("POST", "mostrarJson.php", true);
xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
xhttp.send("producto=" + JSON.stringify(producto));
xhttp.onreadystatechange = function () {
    console.log(xhttp.readyState);
    if (xhttp.readyState == 4 && xhttp.status == 200) {
        alert(xhttp.responseText);
    }
};
