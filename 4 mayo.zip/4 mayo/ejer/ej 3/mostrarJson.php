<?php
  /*  var_dump($_POST);*/ 
    
    $obj = json_decode($_POST["producto"]);
    foreach($obj as $prod)
    {
        echo $prod->codigoBarra." - ".$prod->nombre." - ".$prod->precio."\n";
    }
    
?>