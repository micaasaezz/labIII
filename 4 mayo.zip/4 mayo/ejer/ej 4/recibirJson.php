<?php
  
    $prod = new stdClass();
    $prod->nombre = "chocolate";
    $prod->codigoBarra = 123456789;
    $prod->precio = 10;
    
    echo json_encode($prod);
    
?>