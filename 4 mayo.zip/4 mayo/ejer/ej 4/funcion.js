var producto = { "codigoBarra": 123456789, "nombre": "chocolate", "precio": 10 };
var xhttp = new XMLHttpRequest();
xhttp.open("POST", "recibirJson.php", true);
xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
xhttp.send("producto=" + JSON.stringify(producto));
xhttp.onreadystatechange = function () {
    console.log(xhttp.readyState);
    if (xhttp.readyState == 4 && xhttp.status == 200) {
        console.log(xhttp.responseText);
        var aux = JSON.parse(xhttp.responseText);
        alert(aux["codigoBarra"] + " - " + aux["nombre"] + " - " + aux["precio"]);
    }
};
