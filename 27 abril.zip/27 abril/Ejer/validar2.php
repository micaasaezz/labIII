<?php
    $archivo = fopen("usuarios2.txt", r);
    while(!feof($archivo))
    {
        $datos .= fgets($archivo);
        
    }


    
    fclose($archivo);
?>