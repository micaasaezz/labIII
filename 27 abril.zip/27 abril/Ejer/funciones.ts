function ValidarUsuario():void
{
    let nombre = (<HTMLInputElement>document.getElementById("txtUsuario")).value;
    let pass = (<HTMLInputElement>document.getElementById("txtPass")).value;

    if(nombre != "" && pass != "")
    {
        var xhttp = new XMLHttpRequest();
    
        xhttp.open("GET", "validar.php?usuario="+nombre+"&pass="+pass, true);
        xhttp.send();
        xhttp.onreadystatechange = () => {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    if(xhttp.responseText == "OK") 
                    {
                        (<HTMLInputElement>document.getElementById("body")).style.backgroundColor = "#00FF00";
                    }
                    else
                    {
                        (<HTMLInputElement>document.getElementById("body")).style.backgroundColor = "#FF0000";
                    }
                }
            }
        };
    }

}