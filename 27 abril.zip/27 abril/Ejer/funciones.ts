function ValidarUsuario():void
{
    let nombre = (<HTMLInputElement>document.getElementById("txtUsuario")).value;
    let pass = (<HTMLInputElement>document.getElementById("txtPass")).value;

    if(nombre != "" && pass != "")
    {
        var xhttp = new XMLHttpRequest();
    
        xhttp.open("GET", "validar.php?usuario="+nombre+"&pass="+pass, true);
        xhttp.send();
        xhttp.onreadystatechange = () => {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    if(xhttp.responseText == "OK") 
                    {
                        (<HTMLInputElement>document.getElementById("body")).style.backgroundColor = "#00FF00";
                    }
                    else
                    {
                        (<HTMLInputElement>document.getElementById("body")).style.backgroundColor = "#FF0000";
                    }
                }
            }
        };
    }

}

function TraerTodos():void
{
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", "validar2.php", true);
    xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
    xhttp.send("data=todos");

}
function TraerNombre():void
{
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", "validar2.php", true);
    xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
    xhttp.send("data=nombre");
}   
function TraerArg():void
{
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", "validar2.php", true);
    xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
    xhttp.send("data=arg");
}