<?php
    $archivo = fopen("usuarios.txt", r);
    while(!feof($archivo))
    {
        $datos = explode(" - ", fgets($archivo));
        trim($datos);
        $usuario = $datos[0];
        $pass = $datos[1];

        if($_GET["usuario"] == $usuario && $_GET["pass"] == $pass)
        {
            echo "OK";
            break;
        }
        else
        {
            echo "Not OK!";
        }
    }
    fclose($archivo);
?>