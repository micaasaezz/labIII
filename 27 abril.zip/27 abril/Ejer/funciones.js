"use strict";
function ValidarUsuario() {
    var nombre = document.getElementById("txtUsuario").value;
    var pass = document.getElementById("txtPass").value;
    if (nombre != "" && pass != "") {
        var xhttp = new XMLHttpRequest();
        xhttp.open("GET", "validar.php?usuario=" + nombre + "&pass=" + pass, true);
        xhttp.send();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    if (xhttp.responseText == "OK") {
                        document.getElementById("body").style.backgroundColor = "#00FF00";
                    }
                    else {
                        document.getElementById("body").style.backgroundColor = "#FF0000";
                    }
                }
            }
        };
    }
}
