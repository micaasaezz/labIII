"use strict";
console.log("Hola mundo");
//# sourceMappingURL=main.js.map