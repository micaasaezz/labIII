function PrimerosPrimos() :void
{
    var contador : number = 0;
    var numero : number = 1;
    var divisores : number;
    var i :number;

    while(contador<21)
    {
        divisores =0;
        for(i=0; i<numero; i++)
        {
            if((numero%i) == 0) 
            {
                divisores++;
            }
        }

        if(divisores < 2)
        {
            console.log(`${numero}\n`);
            contador++;
        }
        numero++;
    }
}

PrimerosPrimos();