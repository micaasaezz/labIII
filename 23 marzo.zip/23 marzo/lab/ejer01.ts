console.log(`HOLA MUNDO!!!
Puedo mostrar comillas ‘simples’
Y comillas “dobles”`);