"use strict";
var meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
var i;
for (i = 0; i < 12; i++) {
    console.log(i + " - " + meses[i] + "\n");
}
