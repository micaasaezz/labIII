function MostrarNombreApellido(nombre:string, apellido:string)  :void
{
    nombre = nombre.charAt(0).toUpperCase() + nombre.substr(1,nombre.length -1).toLowerCase();
    console.log(`${apellido.toUpperCase()}, ${nombre}`);
}

MostrarNombreApellido("micAela", "saez");