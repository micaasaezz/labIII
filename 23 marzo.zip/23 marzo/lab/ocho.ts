function Factorial(numero :number) :void
{
    if(numero>0)
    {
        if(numero )
    }
}