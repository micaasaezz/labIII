"use strict";
function EsPar(num) {
    if (num % 2 == 0) {
        console.log("El numero " + num + " es par.");
    }
    else {
        console.log("El numero " + num + " es impar.");
    }
}
funcion(5);
console.log("\n");
funcion(20);
