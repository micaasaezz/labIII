"use strict";
function Factorial(numero) {
    var i;
    if (numero == 1) {
        console.log(numero);
    }
    else {
    }
}
