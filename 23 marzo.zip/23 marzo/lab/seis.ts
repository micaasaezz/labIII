function Cuadrado(num:number) :number
{
    return num*num*num;
}
function Mostrar(numero:number) :void
{
    console.log(Cuadrado(numero));
}

Mostrar(3);