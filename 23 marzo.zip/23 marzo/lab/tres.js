"use strict";
function funcion(requerido, opcional) {
    if (opcional != "") {
        var i;
        for (i = 0; i < requerido; i++) {
            console.log(opcional + "\n");
        }
    }
    else {
        console.log(requerido * (-1));
    }
}
funcion(4);
