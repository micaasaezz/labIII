"use strict";
function Cuadrado(num) {
    return num * num * num;
}
function Mostrar(numero) {
    console.log(Cuadrado(numero));
}
Mostrar(3);
