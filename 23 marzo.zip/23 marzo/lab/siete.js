"use strict";
function PrimerosPrimos() {
    var contador = 0;
    var numero = 1;
    var divisores;
    var i;
    while (contador < 21) {
        divisores = 0;
        for (i = 0; i < numero; i++) {
            if ((numero % i) == 0) {
                divisores++;
            }
        }
        if (divisores < 2) {
            console.log(numero + "\n");
            contador++;
        }
        numero++;
    }
}
PrimerosPrimos();
