"use strict";
console.log("HOLA MUNDO!!!\nPuedo mostrar comillas \u2018simples\u2019\nY comillas \u201Cdobles\u201D");
