<?php
$persona = json_decode(json_encode($_POST["valor"]));
$persona->nombre = "Juan";
echo json_encode($persona);