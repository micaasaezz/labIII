function Saludar() {
    var nombre = $("#txtNombre").val();
    $("#divMostrar").html("Hola " + nombre);
}
function SaludarPhp() {
    var nombre = $("#txtNombre").val();
    $.ajax({
        type:"POST", 
        url:"./BACKEND/backend.php",
        data:"nombre="+nombre,
        dataType:"json",
        async:true
    })
    .done(function(respuesta) {
        $("#divMostrar").html(respuesta.nombre);
    })
    .fail(function() {
        $("#divMostrar").html("errro");
        
    });
}
function SaludarJSON() {
    var nombre = $("#txtNombre").val();
    var json = JSON.parse('{"valor":{"nombre":"'+nombre+'"}}');
    $.ajax({
        type:"POST", 
        url:"./BACKEND/backendJSON.php",
        data:json,
        dataType:"json",
        async:true
    })
    .done(function(respuesta) {
        $("#divMostrar").html(respuesta.nombre);
    })
    .fail(function() {
        $("#divMostrar").html("error");
        
    });        

    /*var json = JSON.parse('{"nombre":"'+nombre+'"}');
    $.ajax({
        type:"POST", 
        url:"backendJSON.php",
        data:"valor="+JSON.stringify(json),
        
        
        $persona = json_decode($_POST["valor"]));
        
        */ 
}